package se.kth.iv1350.integration;


import se.kth.iv1350.model.Sale;

public class ExternalAccountingSystem {
    /**
     * Represents an external accounting system used to update the accounting system
     * with information about a sale. The class isn't necessary according to the assignment
     * And could be completely neglected.
     */
    private int Amount;


    public int getAmount() {
        return Amount;
    }

    /**
     * Updates the external accounting system with information about a sale.
     * Didn't finish it.
     * @param sale The sale for which to update the accounting system.
     */


    public void updateAccountingSystem (Sale sale){

    }

}
