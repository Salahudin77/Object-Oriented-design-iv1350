package se.kth.iv1350.integration;

import se.kth.iv1350.integration.*;


/**
 * this class will log all sales, it was later found out that this class isnt necessary.
 */
public class SaleLog {
    /**
     * Saves information about a sale to a log.
     * @param saleInfo The sale information to be saved.
     */
    public void SavedInfo  (SaleDTO saleInfo){

    }



}
